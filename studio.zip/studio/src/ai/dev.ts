import { config } from 'dotenv';
config();

import '@/ai/flows/climate-risk-estimator.ts';