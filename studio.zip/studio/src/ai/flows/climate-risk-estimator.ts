// src/ai/flows/climate-risk-estimator.ts
'use server';
/**
 * @fileOverview This file defines a Genkit flow for estimating climate risk and suggesting resilience actions.
 *
 * - climateRiskEstimator - A function that takes region data and returns a climate vulnerability index and suggested actions.
 * - ClimateRiskEstimatorInput - The input type for the climateRiskEstimator function.
 * - ClimateRiskEstimatorOutput - The return type for the climateRiskEstimator function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ClimateRiskEstimatorInputSchema = z.object({
  regionType: z
    .string()
    .describe(
      'The type of region (e.g., coastal, arid, urban).  This is free-form text and can contain multiple words.'
    ),
  localEmissionLevels: z
    .string()
    .describe(
      'Description of local emission levels (e.g., high, medium, low). This is free-form text and can contain multiple words.'
    ),
  vegetationCover: z
    .string()
    .describe(
      'Description of vegetation cover in the region (e.g., dense forest, sparse grassland, desert). This is free-form text and can contain multiple words.'
    ),
});

export type ClimateRiskEstimatorInput = z.infer<typeof ClimateRiskEstimatorInputSchema>;

const ClimateRiskEstimatorOutputSchema = z.object({
  climateVulnerabilityIndex: z
    .number()
    .describe('A climate vulnerability index (CVI) from 0-100, with 100 being the most vulnerable.'),
  suggestedActions: z
    .string()
    .describe(
      'A list of suggested climate resilience actions tailored to the region.'
    ),
});

export type ClimateRiskEstimatorOutput = z.infer<typeof ClimateRiskEstimatorOutputSchema>;

export async function climateRiskEstimator(
  input: ClimateRiskEstimatorInput
): Promise<ClimateRiskEstimatorOutput> {
  return climateRiskEstimatorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'climateRiskEstimatorPrompt',
  input: {schema: ClimateRiskEstimatorInputSchema},
  output: {schema: ClimateRiskEstimatorOutputSchema},
  prompt: `You are an expert climate scientist who assesses climate risk and suggests resilience actions.

  Based on the following information about a region, determine its climate vulnerability index (CVI) on a scale of 0-100, where 100 is the most vulnerable. Also, suggest specific climate resilience actions tailored to the region.

  Region Type: {{{regionType}}}
  Local Emission Levels: {{{localEmissionLevels}}}
  Vegetation Cover: {{{vegetationCover}}}

  Output the climate vulnerability index as a number between 0 and 100.
  The suggested actions should be a concise list of actionable steps.
  `,
});

const climateRiskEstimatorFlow = ai.defineFlow(
  {
    name: 'climateRiskEstimatorFlow',
    inputSchema: ClimateRiskEstimatorInputSchema,
    outputSchema: ClimateRiskEstimatorOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
