
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Globe, Thermometer, Droplets, Waves, Wind, Filter,CloudSun, Info, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import Image from "next/image"; 

interface WeatherMetric {
  value: string;
  description: string;
  city?: string;
  icon?: React.ElementType;
  colorClass?: string;
}

interface OpenWeatherData {
  city: string;
  country: string;
  temperature: number;
  feelsLike: number;
  tempMin: number;
  tempMax: number;
  pressure: number;
  humidity: number;
  visibility: number;
  windSpeed: number;
  windDeg: number;
  cloudiness: number;
  weatherMain: string;
  weatherDescription: string;
  weatherIcon: string | null;
  sunrise: number;
  sunset: number;
  timezone: number;
  coordinates: {
    lat: number;
    lon: number;
  };
  rainVolumeLastHour?: number;
  snowVolumeLastHour?: number;
  timestamp: number;
}

const availableCities = [
    { name: "London", lat: 51.5074, lon: 0.1278, country: "GB" },
    { name: "New York", lat: 40.7128, lon: -74.0060, country: "US" },
    { name: "Tokyo", lat: 35.6895, lon: 139.6917, country: "JP" },
    { name: "Paris", lat: 48.8566, lon: 2.3522, country: "FR" },
    { name: "Berlin", lat: 52.5200, lon: 13.4050, country: "DE" },
    { name: "Cairo", lat: 30.0444, lon: 31.2357, country: "EG" },
    { name: "Sydney", lat: -33.8688, lon: 131.2093, country: "AU" }, // Corrected Longitude for Sydney
    { name: "Rio de Janeiro", lat: -22.9068, lon: -43.1729, country: "BR" },
    { name: "Moscow", lat: 55.7558, lon: 37.6173, country: "RU" },
    { name: "Mumbai", lat: 19.0760, lon: 72.8777, country: "IN" },
];


const initialDashboardMetrics: WeatherMetric[] = [
  { value: "N/A", description: "Fetching temperature...", city: "London", icon: Thermometer, colorClass: "text-destructive" },
  { value: "N/A", description: "Fetching weather...", city: "London", icon: CloudSun, colorClass: "text-secondary" },
  { value: "420 ppm", description: "Global atmospheric CO₂ (NOAA, Mauna Loa)", icon: Wind, colorClass: "text-primary" },
  { value: "+3.7 mm/yr", description: "Global avg. sea level rise (NASA/NOAA)", icon: Waves, colorClass: "text-accent" },
];


export default function DashboardPage() {
  const { toast } = useToast();
  const [dashboardCity, setDashboardCity] = useState(availableCities[0]); // Default city for dashboard
  const [dashboardMetrics, setDashboardMetrics] = useState<WeatherMetric[]>(initialDashboardMetrics);
  const [timeRange, setTimeRange] = useState("real-time");
  const [mapImageSeed, setMapImageSeed] = useState<string>("globalmapDefault");

  useEffect(() => {
    // Set initial map image seed on client mount
    setMapImageSeed(`globalmap${Date.now()}`);
  }, []);

  useEffect(() => {
    const fetchWeatherData = async (cityData: typeof availableCities[0]) => {
      try {
        const response = await fetch(`/api/weather?lat=${cityData.lat}&lon=${cityData.lon}`);
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || `Failed to fetch weather for ${cityData.name}`);
        }
        const data: OpenWeatherData = await response.json();
        
        setDashboardMetrics(prevMetrics => {
            const newMetrics = [...prevMetrics];
            newMetrics[0] = { // Temperature
                value: `${data.temperature.toFixed(1)}°C`,
                description: `Current in ${data.city}. Feels like ${data.feelsLike.toFixed(1)}°C. Min: ${data.tempMin.toFixed(1)}°C, Max: ${data.tempMax.toFixed(1)}°C.`,
                city: data.city,
                icon: Thermometer,
                colorClass: "text-destructive"
            };
            newMetrics[1] = { // Weather condition
                value: data.weatherDescription.charAt(0).toUpperCase() + data.weatherDescription.slice(1),
                description: `Conditions in ${data.city}: ${data.cloudiness}% clouds, ${data.humidity}% humidity. Wind: ${data.windSpeed.toFixed(1)} m/s.`,
                city: data.city,
                icon: CloudSun, // Or dynamically choose icon based on data.weatherMain
                colorClass: "text-secondary"
            };
             // Update other metrics with more dynamic simulated data
            newMetrics[2] = { // CO2
                value: `${(415 + Math.random() * 10).toFixed(1)} ppm`,
                description: `Global atmospheric CO₂ (simulated, updated: ${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})})`,
                icon: Wind,
                colorClass: "text-primary"
            };
            newMetrics[3] = { // Sea Level
                value: `+${(3.5 + Math.random() * 0.5).toFixed(1)} mm/yr`,
                description: `Global avg. sea level change (simulated, updated: ${new Date().toLocaleDateString()})`,
                icon: Waves,
                colorClass: "text-accent"
            };
            return newMetrics;
        });

      } catch (error) {
        console.error("Error fetching weather data for dashboard:", error);
        toast({
          title: "Weather Data Error",
          description: `Could not load real-time weather for ${cityData.name}. Displaying last known or simulated data.`,
          variant: "destructive",
        });
        // Fallback to simulated data or clear if preferred
         setDashboardMetrics(prevMetrics => {
            const newMetrics = [...prevMetrics];
            newMetrics[0].value = `~${(Math.random() * 10 + 10).toFixed(1)}°C`;
            newMetrics[0].description = `Error fetching data for ${cityData.name}. Approx. value.`;
            newMetrics[0].city = cityData.name;
            newMetrics[1].value = "Mixed Conditions";
            newMetrics[1].description = `Error fetching data for ${cityData.name}. Conditions N/A.`;
            newMetrics[1].city = cityData.name;
            return newMetrics;
         });
      }
    };

    if (dashboardCity) {
        fetchWeatherData(dashboardCity);
        setMapImageSeed(`globalmap${dashboardCity.name.replace(/\s+/g, '')}${Date.now()}`);
    }
    
    // Simulate fetching other dynamic data for metrics if needed, or update them periodically
    const intervalId = setInterval(() => {
         setDashboardMetrics(prevMetrics => {
            const newMetrics = [...prevMetrics];
            newMetrics[2].value = `${(415 + Math.random() * 10).toFixed(1)} ppm`; // CO2
            newMetrics[2].description = `Global atmospheric CO₂ (simulated, updated: ${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})})`;
            newMetrics[3].value = `+${(3.5 + Math.random() * 0.5).toFixed(1)} mm/yr`; // Sea Level
            newMetrics[3].description = `Global avg. sea level change (simulated, updated: ${new Date().toLocaleDateString()})`;
            return newMetrics;
        });
    }, 60000); // Update simulated global data every minute

    return () => clearInterval(intervalId);

  }, [dashboardCity, toast]);

  const handleFilterClick = () => {
    toast({
      title: "Filters Applied (Simulated)",
      description: "Showing data for selected filters. Actual filtering logic is not yet implemented.",
      variant: "default",
    });
  };
  
  const handleTimeRangeChange = (value: string) => {
     setTimeRange(value);
     toast({title: "Time Range Changed (Simulated)", description: `Displaying data for ${value}. This is currently illustrative.`});
     // In a real app, this would refetch data based on the selected time range
     // For now, we can add some visual cue or slight data change if desired
     setDashboardMetrics(prev => prev.map(m => ({...m, description: m.description.replace(/\(updated: .*\)/, `(updated for ${value})`)})));
  };

  const handleCityChange = (selectedCityName: string) => {
    const cityData = availableCities.find(c => c.name === selectedCityName);
    if (cityData && cityData.name !== dashboardCity.name) {
      setDashboardCity(cityData);
      toast({title: "Dashboard City Changed", description: `Now showing weather for ${cityData.name}.`});
    }
  };


  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Global Climate Dashboard</h1>
          <p className="text-muted-foreground">Visualize climate change (live weather for {dashboardCity.name}, other data simulated).</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select defaultValue={dashboardCity.name} onValueChange={handleCityChange}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Select city" />
            </SelectTrigger>
            <SelectContent>
              {availableCities.map(city => (
                <SelectItem key={city.name} value={city.name}>{city.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select defaultValue={timeRange} onValueChange={handleTimeRangeChange}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="real-time">Real-time Data</SelectItem>
              <SelectItem value="past-24h">Past 24 Hours (Simulated)</SelectItem>
              <SelectItem value="past-7d">Past 7 Days (Simulated)</SelectItem>
              <SelectItem value="past-30d">Past 30 Days (Simulated)</SelectItem>
              <SelectItem value="2000-present">2000 - Present (Simulated Historical)</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={handleFilterClick} className="w-full sm:w-auto">
            <Filter className="mr-2 h-4 w-4" />
            Filters
          </Button>
        </div>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Globe className="text-primary"/> Interactive Climate Map</CardTitle>
          <CardDescription>Global overview of key climate indicators. (Placeholder map)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="aspect-[16/9] bg-muted rounded-lg flex items-center justify-center" data-ai-hint="world map climate">
            {mapImageSeed !== "globalmapDefault" && ( // Only render image if seed is not default (client-side has run)
                <Image
                src={`https://picsum.photos/seed/${mapImageSeed}/1200/675`}
                alt="Global Climate Map Placeholder"
                width={1200}
                height={675}
                className="rounded-md object-cover"
                data-ai-hint="world map climate data"
                key={mapImageSeed} // Re-render image if seed changes
                priority // Prioritize loading this image
                />
            )}
          </div>
          <p className="text-sm text-muted-foreground mt-2 text-center">Note: Interactive map with dynamic data layers coming soon. Current map is a placeholder.</p>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4">
        {dashboardMetrics.map((metric, index) => {
          const IconComponent = metric.icon || TrendingUp; // Default icon
          return (
            <Card key={index} className="shadow-md hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{metric.icon ? `${metric.city ? metric.city + " - " : ""} ${metric.description.split('(')[0].trim()}` : metric.description.split('(')[0].trim()}</CardTitle>
                <IconComponent className={`h-5 w-5 ${metric.colorClass || 'text-primary'}`} />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${metric.colorClass || 'text-primary'}`}>{metric.value}</div>
                <p className="text-xs text-muted-foreground">{metric.description.includes('(') ? metric.description.substring(metric.description.indexOf('(')) : 'Real-time data'}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
       <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Info className="text-primary"/>Data Source Information</CardTitle>
        </CardHeader>
        <CardContent>
            <ul className="list-disc list-inside text-sm space-y-1">
                <li><strong>Current Temperature & Weather:</strong> Real-time data for {dashboardCity.name} via OpenWeatherMap API.</li>
                <li><strong>CO₂ Emissions & Sea Level Change:</strong> Global data points are simulated and updated periodically for illustrative purposes. These values represent typical current estimates from sources like NOAA and NASA.</li>
                <li><strong>Interactive Map:</strong> Placeholder image. A fully interactive map with layered data visualizations (heatmaps, point data) is planned for a future update.</li>
                <li><strong>Time Range Selector:</strong> Currently illustrative. Historical data views and trend analysis will be powered by dedicated climate datasets in future versions.</li>
            </ul>
            <p className="text-xs text-muted-foreground mt-3">This dashboard combines real-time weather information with simulated global climate trend data to provide a comprehensive overview. For in-depth climate analysis, please consult scientific reports and official climate data sources like IPCC, NOAA, NASA, and local meteorological agencies.</p>
        </CardContent>
      </Card>
    </div>
  );
}


      