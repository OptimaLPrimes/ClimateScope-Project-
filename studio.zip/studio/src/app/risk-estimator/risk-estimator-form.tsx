
"use client";

import { useState } from "react";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { climateRiskEstimator, type ClimateRiskEstimatorInput, type ClimateRiskEstimatorOutput } from "@/ai/flows/climate-risk-estimator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, CheckCircle2, Info } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  regionType: z.string().min(3, "Region type must be at least 3 characters long."),
  localEmissionLevels: z.string().min(3, "Emission levels description must be at least 3 characters long."),
  vegetationCover: z.string().min(3, "Vegetation cover description must be at least 3 characters long."),
});

type FormData = z.infer<typeof formSchema>;

export function RiskEstimatorForm() {
  const [result, setResult] = useState<ClimateRiskEstimatorOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      regionType: "",
      localEmissionLevels: "",
      vegetationCover: "",
    },
  });

  const onSubmit: SubmitHandler<FormData> = async (data) => {
    setIsLoading(true);
    setResult(null);
    setError(null);
    try {
      const output = await climateRiskEstimator(data as ClimateRiskEstimatorInput);
      setResult(output);
      toast({
        title: "Risk Estimation Complete",
        description: "Climate Vulnerability Index and suggestions generated.",
        variant: "default",
      });
    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : "An unknown error occurred.";
      setError(`Failed to estimate risk: ${errorMessage}`);
      toast({
        title: "Error",
        description: `Failed to estimate risk: ${errorMessage}`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl">Climate Risk Estimator</CardTitle>
        <CardDescription>
          Enter details about your region to get a Climate Vulnerability Index (CVI) and suggested resilience actions.
        </CardDescription>
      </CardHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="regionType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel htmlFor="regionType">Region Type</FormLabel>
                  <FormControl>
                    <Input id="regionType" placeholder="e.g., Coastal city, Arid plains, Mountain valley" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="localEmissionLevels"
              render={({ field }) => (
                <FormItem>
                  <FormLabel htmlFor="localEmissionLevels">Local Emission Levels</FormLabel>
                   <FormControl>
                    <Input id="localEmissionLevels" placeholder="e.g., High due to industry, Low - mostly residential" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="vegetationCover"
              render={({ field }) => (
                <FormItem>
                  <FormLabel htmlFor="vegetationCover">Vegetation Cover</FormLabel>
                  <FormControl>
                    <Input id="vegetationCover" placeholder="e.g., Dense urban parks, Sparse desert scrub, Agricultural lands" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter className="flex flex-col items-stretch gap-4">
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? "Estimating Risk..." : "Estimate Climate Risk"}
            </Button>
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </CardFooter>
        </form>
      </Form>

      {result && !isLoading && (
        <div className="p-6 border-t">
          <h3 className="text-xl font-semibold mb-4 text-primary">Estimation Results</h3>
          <Card className="mb-6 bg-muted/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="text-accent"/>
                Climate Vulnerability Index (CVI)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Progress value={result.climateVulnerabilityIndex} className="w-full h-6" />
                <span className="text-3xl font-bold text-accent">
                  {result.climateVulnerabilityIndex.toFixed(0)}
                  <span className="text-lg">/100</span>
                </span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                (0 = Least Vulnerable, 100 = Most Vulnerable)
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="text-secondary"/>
                Suggested Resilience Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={result.suggestedActions}
                readOnly
                rows={8}
                className="bg-background text-sm"
              />
            </CardContent>
          </Card>
        </div>
      )}
    </Card>
  );
}
