
"use client";

import { useState, useEffect } from "react";
import Image from "next/image"; 
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Thermometer, Droplets, Waves, Sun, TrendingUp, MapPin, CloudSnow, Wind, Cloud, Umbrella, Sunrise, Sunset, Eye, Gauge } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface OpenWeatherData {
  city: string;
  country: string;
  temperature: number;
  feelsLike: number;
  tempMin: number;
  tempMax: number;
  pressure: number;
  humidity: number;
  visibility: number;
  windSpeed: number;
  windDeg: number;
  cloudiness: number;
  weatherMain: string;
  weatherDescription: string;
  weatherIcon: string | null;
  sunrise: number; // Unix timestamp
  sunset: number;  // Unix timestamp
  timezone: number; 
  coordinates: {
    lat: number;
    lon: number;
  };
  rainVolumeLastHour?: number;
  snowVolumeLastHour?: number;
  timestamp: number;
}

interface CityClimateData {
  // Real-time data from API
  currentTemperature?: string;
  feelsLike?: string;
  weatherDescription?: string;
  weatherIconUrl?: string | null;
  humidity?: string;
  windSpeed?: string;
  windDirection?: string;
  pressure?: string;
  visibility?: string;
  cloudiness?: string;
  sunriseTime?: string;
  sunsetTime?: string;
  rainLastHour?: string;
  snowLastHour?: string;
  dataTimestamp?: string;

  // Simulated/placeholder long-term trend data
  avgTempChangeSimulated: string; // e.g. "+1.5°C since 1960"
  rainfallAnomaliesSimulated: string; // e.g. "+10% annual deviation"
  seaLevelRiseSimulated: string; // e.g. "+5 cm if coastal"
  co2FootprintTrendSimulated: string; // e.g. "Increasing"
  extremeWeatherOutlookSimulated: string; // e.g. "More heatwave days expected"
  
  coords: { lat: number; lon: number };
  isCoastal: boolean; // For simulated sea level rise
  mapImageSeed: string; // For placeholder map image
  cityNameForDisplay: string;
}


const initialCityNamesForPlaceholder = [
  "Chennai", "London", "Paris", "Tokyo", "New York", "Cairo", "Sydney", "Rio de Janeiro", "Moscow", "Mumbai"
];

const getRandomElement = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];


// Generates *only* the simulated/trend part of the data
const generateSimulatedTrendData = (cityName: string): Partial<CityClimateData> => {
  const isCoastalCity = ["New York", "Tokyo", "Sydney", "Rio de Janeiro", "Mumbai", "Chennai"].includes(cityName) || Math.random() > 0.4;
  const trends = ["Sharply Increasing", "Increasing", "Stable", "Slowly Decreasing", "Decreasing"];
  const extremeWeatherTypes = ["more frequent heatwaves", "intense rainfall events", "prolonged droughts", "stronger coastal storms", "unseasonal temperature swings"];
  
  const tempChangeMagnitude = (Math.random() * 2.0 + 0.8).toFixed(1); // +0.8 to +2.8
  const rainfallChangeMagnitude = (Math.random() * 20 + 5).toFixed(1); // 5% to 25%
  const seaLevelChangeMagnitude = isCoastalCity ? (Math.random() * 15 + 5).toFixed(1) : "0"; // 5cm to 20cm if coastal

  return {
    avgTempChangeSimulated: `+${tempChangeMagnitude}°C since 1970 (simulated trend)`,
    rainfallAnomaliesSimulated: `${(Math.random() > 0.5 ? '+' : '-')}${rainfallChangeMagnitude}% annual deviation (simulated trend)`,
    seaLevelRiseSimulated: isCoastalCity ? `+${seaLevelChangeMagnitude} cm (simulated, if coastal)` : "N/A (not coastal or data unavailable)",
    co2FootprintTrendSimulated: `${getRandomElement(trends)} (estimated trend)`,
    extremeWeatherOutlookSimulated: `Expect ${getRandomElement(extremeWeatherTypes)} (simulated projection)`,
    isCoastal: isCoastalCity,
    mapImageSeed: `${cityName.replace(/\s+/g, '')}Map${Date.now()}`,
  };
};


// Helper to convert UNIX timestamp to local time string
const formatUnixTimestamp = (timestamp: number, timezoneOffset: number): string => {
  const date = new Date((timestamp + timezoneOffset) * 1000); // Add timezoneOffset (in seconds) and convert to ms
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', timeZone: 'UTC' }); // Display as UTC after offset
};

// Helper for wind direction
const getWindDirection = (degrees: number): string => {
    const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
    return directions[Math.round(degrees / 22.5) % 16];
};


export default function CityTrackerPage() {
  const [cityInput, setCityInput] = useState("");
  const [searchedCityName, setSearchedCityName] = useState<string | null>(null);
  const [cityClimateData, setCityClimateData] = useState<CityClimateData | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [placeholderCity, setPlaceholderCity] = useState<string>("London"); // Default static placeholder

  useEffect(() => {
    // Set a random placeholder city only on the client-side after hydration
    setPlaceholderCity(getRandomElement(initialCityNamesForPlaceholder));
  }, []);


  const handleSearch = async (searchQuery?: string) => {
    const currentCityToSearch = searchQuery || cityInput;
    if (!currentCityToSearch) {
      toast({
        title: "Input Required",
        description: "Please enter a city name.",
        variant: "destructive",
      });
      return;
    }
    setLoading(true);
    setSearchedCityName(currentCityToSearch);
    setCityClimateData(null); // Clear previous data
    
    try {
      const response = await fetch(`/api/weather?city=${encodeURIComponent(currentCityToSearch)}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Weather data not found for ${currentCityToSearch}. Please check the city name or try another location.`);
      }
      const weatherData: OpenWeatherData = await response.json();
      
      const simulatedTrends = generateSimulatedTrendData(weatherData.city) as Partial<CityClimateData>;

      const combinedData: CityClimateData = {
        ...simulatedTrends, // Spread simulated trends first
        cityNameForDisplay: `${weatherData.city}, ${weatherData.country}`,
        currentTemperature: `${weatherData.temperature.toFixed(1)}°C`,
        feelsLike: `${weatherData.feelsLike.toFixed(1)}°C`,
        weatherDescription: weatherData.weatherDescription.charAt(0).toUpperCase() + weatherData.weatherDescription.slice(1),
        weatherIconUrl: weatherData.weatherIcon,
        humidity: `${weatherData.humidity}%`,
        windSpeed: `${weatherData.windSpeed.toFixed(1)} m/s`,
        windDirection: weatherData.windDeg !== undefined ? getWindDirection(weatherData.windDeg) : "N/A",
        pressure: `${weatherData.pressure} hPa`,
        visibility: weatherData.visibility ? `${(weatherData.visibility / 1000).toFixed(1)} km` : "N/A",
        cloudiness: `${weatherData.cloudiness}%`,
        sunriseTime: weatherData.sunrise ? formatUnixTimestamp(weatherData.sunrise, weatherData.timezone) : "N/A",
        sunsetTime: weatherData.sunset ? formatUnixTimestamp(weatherData.sunset, weatherData.timezone) : "N/A",
        rainLastHour: weatherData.rainVolumeLastHour ? `${weatherData.rainVolumeLastHour.toFixed(1)} mm` : undefined,
        snowLastHour: weatherData.snowVolumeLastHour ? `${weatherData.snowVolumeLastHour.toFixed(1)} mm` : undefined,
        dataTimestamp: weatherData.timestamp ? `As of ${new Date(weatherData.timestamp * 1000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', timeZoneName: 'short'})}`: "Timestamp N/A",
        coords: weatherData.coordinates,
        isCoastal: simulatedTrends.isCoastal !== undefined ? simulatedTrends.isCoastal : Math.random() > 0.5, 
        mapImageSeed: simulatedTrends.mapImageSeed || `${weatherData.city.replace(/\s+/g, '')}MapFallback${Date.now()}`,

      };
      
      setCityClimateData(combinedData);
      toast({
        title: "Data Loaded",
        description: `Current weather and simulated climate insights for ${weatherData.city} are now displayed.`,
      });

    } catch (error) {
      const errMsg = error instanceof Error ? error.message : "An unknown error occurred.";
      toast({
        title: "Error Fetching Data",
        description: errMsg,
        variant: "destructive",
      });
      // Provide some minimal data for display even on error for the searched city
      const simulatedForError = generateSimulatedTrendData(currentCityToSearch);
      setCityClimateData({
        cityNameForDisplay: currentCityToSearch,
        coords: { lat: 0, lon: 0 }, // Placeholder coords
        ...simulatedForError,
        avgTempChangeSimulated: simulatedForError.avgTempChangeSimulated || "N/A",
        rainfallAnomaliesSimulated: simulatedForError.rainfallAnomaliesSimulated || "N/A",
        seaLevelRiseSimulated: simulatedForError.seaLevelRiseSimulated || "N/A",
        co2FootprintTrendSimulated: simulatedForError.co2FootprintTrendSimulated || "N/A",
        extremeWeatherOutlookSimulated: simulatedForError.extremeWeatherOutlookSimulated || "N/A",
        isCoastal: simulatedForError.isCoastal !== undefined ? simulatedForError.isCoastal : false,
        mapImageSeed: simulatedForError.mapImageSeed || `${currentCityToSearch}ErrorMap${Date.now()}`
      });
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
         <div>
            <h1 className="text-3xl font-bold tracking-tight text-primary">My City Climate Tracker</h1>
            <p className="text-muted-foreground">Get current weather and simulated long-term climate trends for your city.</p>
        </div>
      </div>
      
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><MapPin className="text-primary"/>City Search</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex w-full max-w-md items-center space-x-2">
            <Input
              type="text"
              placeholder={`Enter city (e.g., ${placeholderCity})`}
              value={cityInput}
              onChange={(e) => setCityInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="flex-grow"
            />
            <Button onClick={() => handleSearch()} disabled={loading}>
              {loading ? "Searching..." : "Search"}
            </Button>
          </div>
          <p className="text-sm text-muted-foreground mt-2">Enter a city name to see its current weather and simulated climate data trends, plus a placeholder map.</p>
          <div 
            className="mt-4 aspect-[16/9] bg-muted rounded-lg flex items-center justify-center"
            data-ai-hint="city map location"
          >
            {searchedCityName && cityClimateData ? (
               <Image src={`https://picsum.photos/seed/${cityClimateData.mapImageSeed}/800/450`} alt={`Map of ${searchedCityName}`} width={800} height={450} className="rounded-md object-cover" data-ai-hint="city map" />
            ) : (
              <div className="text-muted-foreground">Search for a city to display its map and data.</div>
            )}
          </div>
        </CardContent>
      </Card>

      {searchedCityName && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Climate Insights for {cityClimateData?.cityNameForDisplay || searchedCityName}</CardTitle>
            {loading && <CardDescription>Loading data...</CardDescription>}
            {!loading && !cityClimateData?.currentTemperature && <CardDescription className="text-destructive">Current weather data unavailable for {searchedCityName}. Showing simulated trends only.</CardDescription>}
            {cityClimateData?.dataTimestamp && <CardDescription className="text-xs text-muted-foreground">{cityClimateData.dataTimestamp}</CardDescription>}
          </CardHeader>
          {cityClimateData && !loading && (
            <CardContent className="space-y-6">
              {cityClimateData.currentTemperature && (
                <div>
                  <h3 className="text-xl font-semibold mb-3 text-secondary">Current Weather Conditions</h3>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <InfoCard icon={Thermometer} title="Temperature" value={cityClimateData.currentTemperature || "N/A"} unit={cityClimateData.feelsLike ? `Feels like ${cityClimateData.feelsLike}` : undefined} />
                    <InfoCard icon={Umbrella} title="Weather" value={cityClimateData.weatherDescription || "N/A"} iconUrl={cityClimateData.weatherIconUrl}/>
                    <InfoCard icon={Droplets} title="Humidity" value={cityClimateData.humidity || "N/A"} />
                    <InfoCard icon={Wind} title="Wind" value={cityClimateData.windSpeed || "N/A"} unit={cityClimateData.windDirection} />
                    <InfoCard icon={Gauge} title="Pressure" value={cityClimateData.pressure || "N/A"} />
                    <InfoCard icon={Eye} title="Visibility" value={cityClimateData.visibility || "N/A"} />
                    <InfoCard icon={Cloud} title="Cloudiness" value={cityClimateData.cloudiness || "N/A"} />
                    {cityClimateData.rainLastHour && <InfoCard icon={Droplets} title="Rain (1h)" value={cityClimateData.rainLastHour} />}
                    {cityClimateData.snowLastHour && <InfoCard icon={CloudSnow} title="Snow (1h)" value={cityClimateData.snowLastHour} />}
                    <InfoCard icon={Sunrise} title="Sunrise" value={cityClimateData.sunriseTime || "N/A"} />
                    <InfoCard icon={Sunset} title="Sunset" value={cityClimateData.sunsetTime || "N/A"} />
                  </div>
                </div>
              )}
              
              <div>
                <h3 className="text-xl font-semibold my-4 pt-4 border-t text-secondary">Simulated Long-Term Climate Trends</h3>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <InfoCard icon={TrendingUp} title="Avg. Temp Change (Simulated)" value={cityClimateData.avgTempChangeSimulated} unit="since 1970" />
                    <InfoCard icon={Droplets} title="Rainfall Anomalies (Simulated)" value={cityClimateData.rainfallAnomaliesSimulated} unit="annual deviation" />
                    <InfoCard icon={Waves} title="Sea Level Rise (Simulated)" value={cityClimateData.seaLevelRiseSimulated} unit={cityClimateData.isCoastal ? "if coastal" : "N/A"} />
                    <InfoCard icon={Sun} title="Extreme Weather (Simulated)" value={cityClimateData.extremeWeatherOutlookSimulated} unit="long-term projection" />
                    <InfoCard icon={TrendingUp} title="CO₂ Footprint Trend (Simulated)" value={cityClimateData.co2FootprintTrendSimulated} unit="estimated" />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2 mt-4">
                <Card>
                  <CardHeader><CardTitle>Temperature Trend (Conceptual)</CardTitle></CardHeader>
                  <CardContent className="h-60 bg-muted rounded-md flex items-center justify-center">
                     <Image src={`https://picsum.photos/seed/${cityClimateData.mapImageSeed}Temp/400/240`} alt={`Conceptual temperature trend for ${searchedCityName}`} width={400} height={240} className="rounded-md object-contain" data-ai-hint="temperature chart graph" />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader><CardTitle>Precipitation Pattern (Conceptual)</CardTitle></CardHeader>
                   <CardContent className="h-60 bg-muted rounded-md flex items-center justify-center">
                     <Image src={`https://picsum.photos/seed/${cityClimateData.mapImageSeed}Rain/400/240`} alt={`Conceptual rainfall pattern for ${searchedCityName}`} width={400} height={240} className="rounded-md object-contain" data-ai-hint="rainfall chart graph" />
                  </CardContent>
                </Card>
              </div>
              {cityClimateData.isCoastal && cityClimateData.seaLevelRiseSimulated !== "N/A (not coastal or data unavailable)" && (
                 <Card>
                    <CardHeader><CardTitle>Sea Level Rise Overlay (Conceptual)</CardTitle></CardHeader>
                    <CardContent className="h-80 bg-muted rounded-md flex items-center justify-center">
                         <Image src={`https://picsum.photos/seed/${cityClimateData.mapImageSeed}Sea/600/320`} alt={`Conceptual sea level rise map for ${searchedCityName}`} width={600} height={320} className="rounded-md object-contain" data-ai-hint="sea level map" />
                    </CardContent>
                </Card>
              )}
              <p className="text-xs text-muted-foreground mt-4">Note: Long-term trend data is simulated for illustrative purposes. Current weather data is from OpenWeatherMap.</p>
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
}

interface InfoCardProps {
  icon: React.ElementType;
  title: string;
  value: string;
  unit?: string;
  iconUrl?: string | null;
}

const InfoCard = ({ icon: Icon, title, value, unit, iconUrl }: InfoCardProps) => (
  <Card className="shadow-sm hover:shadow-md transition-shadow">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      {iconUrl ? (
        <Image src={iconUrl} alt={title} width={24} height={24} className="h-6 w-6" />
      ) : (
        <Icon className="h-5 w-5 text-primary" />
      )}
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      {unit && <p className="text-xs text-muted-foreground">{unit}</p>}
    </CardContent>
  </Card>
);


      