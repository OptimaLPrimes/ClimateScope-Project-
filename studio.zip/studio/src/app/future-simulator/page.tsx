
"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Thermometer, CloudRain, ShieldAlert, Zap, Waves, TrendingUp, Sun, Wind, Mountain, Building, Leaf } from "lucide-react"; 
import { useToast } from "@/hooks/use-toast";

interface BasePrediction {
  baseAvgTemp: [number, number]; // [min, max] relative to pre-industrial
  rainfallPatterns: string[];
  floodRisk: string[];
  wildfireDroughtLikelihood: string[];
  seaLevelRise?: [number, number]; // [min, max] cm, optional
  extremeEvents?: string[]; 
  ecoImpacts?: string[];
}

const baseScenarioData: Record<string, BasePrediction> = {
  "SSP1-2.6": { // Sustainability – Taking the Green Road
    baseAvgTemp: [1.3, 1.9], // slightly wider range
    rainfallPatterns: ["Slight increase in total, more intense localized events", "Generally stable with regional variations, improved predictability", "More predictable, but with occasional extremes like intense short bursts"],
    floodRisk: ["Moderate increase in known vulnerable areas, largely mitigated by proactive measures", "Localized increases, overall manageable with strong adaptation efforts", "Slight increase, primarily affecting unprepared coastal and riverside areas"],
    wildfireDroughtLikelihood: ["Slightly increased risk of regional droughts, wildfires effectively managed", "Occasional moderate droughts in historically susceptible regions, wildfire spread limited", "Wildfire risk increase minimal with global proactive land management and fire suppression"],
    seaLevelRise: [28, 55], // IPCC AR6 low-end
    extremeEvents: ["Fewer extreme heatwaves compared to higher scenarios, but still more than historical", "Some increase in localized storm intensity and heavy precipitation", "Droughts less severe but potentially more frequent in certain regions"],
    ecoImpacts: ["Coral reef bleaching significantly reduced but not eliminated", "Moderate shifts in species distribution", "Improved biodiversity conservation efforts show positive results"],
  },
  "SSP2-4.5": { // Middle of the Road
    baseAvgTemp: [2.1, 3.5], // IPCC AR6 mid-range
    rainfallPatterns: ["More erratic, significant regional variations in amount and timing", "Increased frequency of heavy downpours and flash floods in some areas", "Longer, more intense dry spells in semi-arid and arid regions"],
    floodRisk: ["Significant increase in flood frequency and extent, impacting more urban and rural areas", "Riverine and coastal flooding becomes a major concern requiring substantial defense investment", "Flash flood risk elevated across multiple topographies"],
    wildfireDroughtLikelihood: ["Moderate to significant increase in both wildfire acreage burned and drought duration/intensity", "Increased probability of 'mega-droughts' in continental interiors and Mediterranean-like climates", "Wildfire season extends significantly, posing year-round threats in some areas"],
    seaLevelRise: [44, 76], // IPCC AR6 mid-range
    extremeEvents: ["Noticeable increase in heatwave frequency, intensity, and duration", "More powerful hurricanes/cyclones with higher peak wind speeds and rainfall", "Compound events (e.g., drought followed by intense rain and flood) become more likely"],
    ecoImpacts: ["Widespread coral reef mortality", "Significant biodiversity loss and ecosystem disruption", "Agricultural yields impacted negatively in many regions"],
  },
  "SSP5-8.5": { // Fossil-fueled Development – Taking the Highway
    baseAvgTemp: [3.8, 5.7], // IPCC AR6 high-end
    rainfallPatterns: ["Extreme variability, with severe droughts and catastrophic floods becoming common", "Atmospheric rivers become more common and intense, leading to widespread inundation", "Rainfall distribution highly unpredictable, leading to systemic water crises"],
    floodRisk: ["Very high, widespread and frequent flooding, critical infrastructure (energy, transport, water) at severe risk or failing", "Permanent inundation of some coastal cities and large land areas", "Pluvial (surface water) flooding overwhelms urban drainage systems regularly"],
    wildfireDroughtLikelihood: ["High and persistent risk of prolonged, severe droughts and uncontrollable megafires across multiple continents", "Ecosystems transition to fire-adapted or desertified states", "Water scarcity becomes a critical global issue, leading to conflict and displacement"],
    seaLevelRise: [63, 101], // IPCC AR6 high-end (up to 1.3m with ice sheet instability)
    extremeEvents: ["Frequent, prolonged, and dangerous heatwaves, potentially lethal for vulnerable populations", "Category 5+ storms become more common, with unprecedented destructive potential", "Cascading climate failures impacting multiple sectors (food, water, energy, health) simultaneously"],
    ecoImpacts: ["Irreversible loss of most coral reefs and many coastal ecosystems", "Mass extinction events and collapse of major biomes (e.g., Amazon rainforest, boreal forests)", "Global food production severely threatened"],
  },
};

type ScenarioKey = keyof typeof baseScenarioData;

interface GeneratedPredictionData {
  avgTemp: string;
  rainfallPatterns: string;
  floodRisk: string;
  wildfireDroughtLikelihood: string;
  seaLevelRiseInfo?: string;
  extremeEventsInfo?: string;
  adaptationFocus?: string;
  ecoImpactsInfo?: string;
  regionalNuances?: string;
}

const lifestyleModifiers = {
  sustainable: { tempMultiplier: 0.9, riskReduction: 0.25, adaptation: "Proactive, nature-based solutions, strong community resilience, circular economy principles.", ecoBonus: 0.15 },
  current: { tempMultiplier: 1.0, riskReduction: 0, adaptation: "Reactive adaptation, mix of grey and green infrastructure, moderate policy implementation.", ecoBonus: 0 },
  "carbon-heavy": { tempMultiplier: 1.1, riskReduction: -0.2, adaptation: "Heavy reliance on engineered solutions, delayed action, focus on disaster response over prevention.", ecoBonus: -0.1 },
};

const cityArchetypes = {
    coastal: { nuances: "Enhanced focus on sea-level rise, storm surges, and saltwater intrusion. Potential for blue carbon initiatives.", icon: Waves },
    mountain: { nuances: "Concerns for glacier melt, changes in snowpack affecting water supply, landslide risks, and shifts in alpine ecosystems.", icon: Mountain },
    urban: { nuances: "Heat island effect amplification, strain on urban drainage and infrastructure, air quality concerns, and social vulnerability hotspots.", icon: Building },
    rural: { nuances: "Impacts on agriculture and forestry, water resource management for irrigation, biodiversity in surrounding natural areas.", icon: Leaf },
    generic: { nuances: "General climate impacts applicable across diverse settings, adjust focus based on specific inputs.", icon: Sun }
};
type CityArchetypeKey = keyof typeof cityArchetypes;


const getRandomElement = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

const generateSimulatedPredictions = (
  scenarioKey: ScenarioKey,
  city: string, 
  lifestyle: keyof typeof lifestyleModifiers,
  cityArchetypeKey: CityArchetypeKey
): GeneratedPredictionData => {
  const base = baseScenarioData[scenarioKey];
  const modifier = lifestyleModifiers[lifestyle];
  const archetype = cityArchetypes[cityArchetypeKey];

  const tempMin = base.baseAvgTemp[0] * modifier.tempMultiplier + (Math.random() * 0.5 - 0.25); // increased variability
  const tempMax = base.baseAvgTemp[1] * modifier.tempMultiplier + (Math.random() * 0.6 - 0.3); // increased variability

  let seaLevelRiseInfo: string | undefined = undefined;
  if (base.seaLevelRise && (cityArchetypeKey === 'coastal' || Math.random() < 0.3)) { // Higher chance for coastal, small chance for others if near large water bodies
    const slrMin = base.seaLevelRise[0] * modifier.tempMultiplier + (Math.random() * 15 - 7); // wider variability
    const slrMax = base.seaLevelRise[1] * modifier.tempMultiplier + (Math.random() * 20 - 10); // wider variability
    seaLevelRiseInfo = `Approx. +${Math.max(0, slrMin).toFixed(0)}-${Math.max(slrMin, slrMax).toFixed(0)} cm (highly variable, influenced by local topography and ocean currents).`;
  }
  
  const riskLevelWords = ["Very Low", "Low", "Moderate", "High", "Very High", "Extreme"];
  const applyRiskModification = (baseRiskString: string): string => {
    let baseIndex = Math.floor(Math.random() * 2) + 2; // Default to Moderate/High
    if (baseRiskString.toLowerCase().includes("low")) baseIndex = 1;
    if (baseRiskString.toLowerCase().includes("high") || baseRiskString.toLowerCase().includes("significant")) baseIndex = 3;
    if (baseRiskString.toLowerCase().includes("very high") || baseRiskString.toLowerCase().includes("critical")) baseIndex = 4;
    
    let modifiedIndex = Math.round(baseIndex - (riskLevelWords.length-1) * modifier.riskReduction + (Math.random()*0.4-0.2)); // add small noise
    modifiedIndex = Math.max(0, Math.min(riskLevelWords.length - 1, modifiedIndex));
    return riskLevelWords[modifiedIndex];
  };


  return {
    avgTemp: `Projected +${tempMin.toFixed(1)}°C to +${tempMax.toFixed(1)}°C (vs. pre-industrial, ${city} specific microclimates may vary).`,
    rainfallPatterns: getRandomElement(base.rainfallPatterns) + ` Water availability in ${city} will be a key challenge.`,
    floodRisk: `${getRandomElement(base.floodRisk)} (Overall Risk for ${city}: ${applyRiskModification(getRandomElement(base.floodRisk))})`,
    wildfireDroughtLikelihood: `${getRandomElement(base.wildfireDroughtLikelihood)} (Threat Level for ${city} region: ${applyRiskModification(getRandomElement(base.wildfireDroughtLikelihood))})`,
    seaLevelRiseInfo,
    extremeEventsInfo: base.extremeEvents ? getRandomElement(base.extremeEvents) + ` (frequency and intensity influenced by global emissions pathway and local preparedness in ${city}).` : `General increase in climate-related extremes for ${city}.`,
    adaptationFocus: modifier.adaptation + ` Specific strategies for ${city} should include: ${archetype.nuances}`,
    ecoImpactsInfo: base.ecoImpacts ? getRandomElement(base.ecoImpacts) + (modifier.ecoBonus > 0 ? " Efforts towards sustainability may mitigate some local impacts." : (modifier.ecoBonus < 0 ? " High carbon pathway exacerbates ecological damage." : "")) : `Significant ecological shifts expected around ${city}.`,
    regionalNuances: `For ${city} (${cityArchetypeKey}): ${archetype.nuances}`
  };
};


export default function FutureSimulatorPage() {
  const [city, setCity] = useState("");
  const [scenario, setScenario] = useState<ScenarioKey>("SSP2-4.5");
  const [lifestyle, setLifestyle] = useState<keyof typeof lifestyleModifiers>("current");
  const [cityArchetype, setCityArchetype] = useState<CityArchetypeKey>("generic");
  const [predictions, setPredictions] = useState<GeneratedPredictionData | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [imageSeed, setImageSeed] = useState<number>(0); // Initialize with a static value or 0

  useEffect(() => {
    // Set initial image seed on client mount to avoid hydration mismatch
    setImageSeed(Date.now());
  }, []);


  const handleSimulate = () => {
    if (!city) {
      toast({ title: "City Required", description: "Please enter a city name to start simulation.", variant: "destructive"});
      return;
    }
    setLoading(true);
    setPredictions(null); 
    
    // Simulate API call
    setTimeout(() => {
      const generatedPreds = generateSimulatedPredictions(scenario, city, lifestyle, cityArchetype);
      setPredictions(generatedPreds);
      setImageSeed(Date.now()); // Change image seed for new simulation
      setLoading(false);
      toast({
        title: "Simulation Complete!",
        description: `Future projection for ${city} under ${scenario} (${lifestyle} path, ${cityArchetype} type) is ready.`,
      });
    }, 1500 + Math.random() * 1000); // variable loading time
  };

  const ArchetypeIcon = cityArchetypes[cityArchetype].icon;


  return (
    <div className="space-y-6">
       <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
         <div>
            <h1 className="text-3xl font-bold tracking-tight text-primary">Your City in 2050 Simulator</h1>
            <p className="text-muted-foreground">Explore potential climate futures based on IPCC scenarios, societal paths, and city types.</p>
        </div>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><TrendingUp className="text-primary"/>Simulation Setup</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label htmlFor="cityInput" className="block text-sm font-medium text-foreground mb-1">Your City</label>
              <Input
                id="cityInput"
                type="text"
                placeholder="Enter city name (e.g., London)"
                value={city}
                onChange={(e) => setCity(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="cityArchetypeSelect" className="block text-sm font-medium text-foreground mb-1">City Archetype</label>
              <Select value={cityArchetype} onValueChange={(value) => setCityArchetype(value as CityArchetypeKey)}>
                <SelectTrigger id="cityArchetypeSelect">
                  <SelectValue placeholder="Select City Type" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(cityArchetypes).map(([key, val]) => (
                    <SelectItem key={key} value={key}>
                       <div className="flex items-center gap-2">
                        <val.icon className="h-4 w-4 text-muted-foreground" />
                        {key.charAt(0).toUpperCase() + key.slice(1)}
                       </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label htmlFor="scenarioSelect" className="block text-sm font-medium text-foreground mb-1">IPCC Scenario (2050)</label>
              <Select value={scenario} onValueChange={(value) => setScenario(value as ScenarioKey)}>
                <SelectTrigger id="scenarioSelect">
                  <SelectValue placeholder="Select IPCC Scenario" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="SSP1-2.6">SSP1-2.6 (Sustainability)</SelectItem>
                  <SelectItem value="SSP2-4.5">SSP2-4.5 (Middle Road)</SelectItem>
                  <SelectItem value="SSP5-8.5">SSP5-8.5 (Fossil-fueled Dev.)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label htmlFor="lifestyleSelect" className="block text-sm font-medium text-foreground mb-1">Societal Path</label>
              <Select value={lifestyle} onValueChange={(value) => setLifestyle(value as keyof typeof lifestyleModifiers)}>
                <SelectTrigger id="lifestyleSelect">
                  <SelectValue placeholder="Select Societal Path" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sustainable">Sustainable Path</SelectItem>
                  <SelectItem value="current">Current Trajectory</SelectItem>
                  <SelectItem value="carbon-heavy">Carbon-Heavy Path</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
           <p className="text-xs text-muted-foreground mt-1">Note: Societal path & city type significantly modify simulation outcomes.</p>
          <Button onClick={handleSimulate} disabled={loading || !city} className="w-full md:w-auto">
            {loading ? "Simulating..." : "Simulate Future"}
          </Button>
        </CardContent>
      </Card>

      {predictions && !loading && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <ArchetypeIcon className="h-7 w-7 text-primary" /> 
                2050 Climate Predictions for {city} 
            </CardTitle>
            <CardDescription>Scenario: {scenario} | Societal Path: {lifestyle.charAt(0).toUpperCase() + lifestyle.slice(1)} | Archetype: {cityArchetype.charAt(0).toUpperCase() + cityArchetype.slice(1)}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <PredictionItem icon={Thermometer} title="Expected Avg. Temperature" value={predictions.avgTemp} />
              <PredictionItem icon={CloudRain} title="Rainfall Patterns" value={predictions.rainfallPatterns} />
              <PredictionItem icon={ShieldAlert} title="Flood Risk" value={predictions.floodRisk} />
              <PredictionItem icon={Zap} title="Wildfire & Drought Likelihood" value={predictions.wildfireDroughtLikelihood} />
              {predictions.seaLevelRiseInfo && <PredictionItem icon={Waves} title="Sea Level Rise" value={predictions.seaLevelRiseInfo} />}
              {predictions.extremeEventsInfo && <PredictionItem icon={Wind} title="Extreme Events Outlook" value={predictions.extremeEventsInfo} /> }
              {predictions.ecoImpactsInfo && <PredictionItem icon={Leaf} title="Ecological Impacts" value={predictions.ecoImpactsInfo} />}
            </div>
             {predictions.regionalNuances && (
                <div className="mt-4 p-4 bg-muted/60 rounded-md">
                    <h4 className="font-semibold text-foreground/90 mb-1 flex items-center gap-2"><ArchetypeIcon className="h-5 w-5 text-primary"/>Regional Considerations for {city} ({cityArchetype}):</h4>
                    <p className="text-sm text-muted-foreground">{predictions.regionalNuances.split(cityArchetype + "): ")[1]}</p>
                </div>
            )}
            {predictions.adaptationFocus && (
                <div className="mt-4 p-4 bg-secondary/10 rounded-md">
                    <h4 className="font-semibold text-secondary mb-1">Adaptation Focus:</h4>
                    <p className="text-sm text-secondary-foreground/90">{predictions.adaptationFocus.split("Specific strategies")[0]}</p>
                </div>
            )}
             <div className="mt-6 p-4 bg-muted rounded-md text-center">
                <p className="text-lg font-semibold">Visualizing {city} in 2050 ({scenario}, {lifestyle} path)</p>
                <div className="mt-2 aspect-video bg-gray-300 rounded-lg flex items-center justify-center">
                     {imageSeed !== 0 && ( // Only render image if seed is set (client-side)
                        <Image 
                            src={`https://picsum.photos/seed/${imageSeed}-${city}-${scenario}-${lifestyle}/800/450`}
                            alt={`Simulated view of ${city} in 2050 under ${scenario} scenario with ${lifestyle} lifestyle and ${cityArchetype} type.`}
                            width={800}
                            height={450}
                            className="rounded-md object-cover"
                            key={`${imageSeed}-${city}-${scenario}-${lifestyle}`} // Force re-render of image on seed change
                            data-ai-hint="city future climate"
                        />
                    )}
                </div>
                <p className="text-sm text-muted-foreground mt-2">Conceptual visualization based on selected scenario and societal path.</p>
            </div>
          </CardContent>
        </Card>
      )}
       {loading && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Simulating future for {city}...</CardTitle>
          </CardHeader>
          <CardContent className="text-center py-10">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Gathering climate model data and crunching numbers for {city} ({scenario}, {lifestyle}, {cityArchetype})...</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

interface PredictionItemProps {
  icon: React.ElementType;
  title: string;
  value: string;
}

const PredictionItem = ({ icon: Icon, title, value }: PredictionItemProps) => (
  <Card className="shadow-sm hover:shadow-md transition-shadow bg-background/70">
    <CardHeader className="flex flex-row items-start gap-3 space-y-0 pb-2 pt-4">
      <Icon className="h-6 w-6 text-primary mt-1" />
      <CardTitle className="text-md font-medium">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="text-foreground/90 text-sm">{value}</p>
    </CardContent>
  </Card>
);


      