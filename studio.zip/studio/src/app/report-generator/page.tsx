
"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Download, Thermometer, Droplets, Waves, Sun, Leaf, ShieldCheck, AlertTriangle, BarChart3, Map } from "lucide-react";
import Image from "next/image";
import { useToast } from "@/hooks/use-toast";

const getRandomElement = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const getRandomElements = <T,>(arr: T[], count: number): T[] => {
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, Math.min(count, shuffled.length));
};

const sampleKeyRisksPool = [
  "Increased frequency and intensity of heatwaves impacting public health and energy demand.",
  "Water scarcity due to prolonged droughts, altered rainfall patterns, and increased evapotranspiration.",
  "Coastal inundation, erosion, and saltwater intrusion from sea-level rise and more intense storm surges.",
  "Disruption to agricultural yields and food security due to changing temperatures, water availability, and pest patterns.",
  "Damage to critical infrastructure (transport, energy, water systems, communication) from extreme weather events.",
  "Increased risk of vector-borne diseases (e.g., malaria, dengue) spreading to new geographical areas.",
  "Loss of biodiversity, ecosystem degradation, and shifts in species distribution affecting natural resources.",
  "More frequent and severe wildfires threatening communities, habitats, and air quality.",
  "Urban flooding due to overwhelmed drainage systems during heavy rainfall and increased impervious surfaces.",
  "Impacts on tourism and recreation-based economies due to environmental changes and extreme events.",
  "Supply chain disruptions for essential goods and services due to climate-related disasters globally and locally.",
  "Social inequities exacerbated by climate impacts, disproportionately affecting vulnerable populations.",
  "Glacier and snowpack melt impacting freshwater availability downstream and increasing flood risk.",
  "Ocean acidification threatening marine ecosystems and fisheries.",
  "Mental health impacts from climate anxiety, displacement, and disaster trauma.",
];

const sampleMitigationAdvicePool = [
  "Accelerate transition to renewable energy sources (solar, wind, geothermal, sustainable hydro).",
  "Improve energy efficiency across all sectors: buildings, transport, industry, and agriculture.",
  "Invest in and expand sustainable public transportation, cycling, and walking infrastructure.",
  "Protect, restore, and sustainably manage forests, wetlands, mangroves, and peatlands as crucial carbon sinks.",
  "Implement sustainable land management, agroforestry, and regenerative agricultural practices.",
  "Support research, development, and deployment of carbon capture, utilization, and storage (CCUS) technologies where appropriate.",
  "Promote circular economy models to reduce waste, improve resource efficiency, and minimize emissions from production.",
  "Strengthen and expand early warning systems for all types of climate-related hazards.",
  "Invest in resilient infrastructure, including upgrading coastal defenses (sea walls, dunes, living shorelines, ecosystem-based adaptation).",
  "Develop and promote drought-resistant crops, water-efficient irrigation systems, and integrated water resource management.",
  "Implement urban greening initiatives (parks, green roofs, permeable pavements) for cooling, water management, and biodiversity.",
  "Update and enforce climate-resilient building codes and infrastructure standards.",
  "Foster community-based adaptation planning and empower local action through funding and technical support.",
  "Invest in climate research, observation systems, and innovation for better understanding and response.",
  "Promote international cooperation, technology transfer, and financial support for climate action in developing countries.",
  "Implement carbon pricing mechanisms (e.g., carbon tax, cap-and-trade) to incentivize emissions reductions.",
  "Support public awareness campaigns and education on climate change causes, impacts, and solutions.",
];


interface ReportData {
  location: string;
  reportTitle: string;
  dateGenerated: string;
  currentTrends: {
    temperature: string;
    precipitation: string;
    seaLevel?: string; // Optional for non-coastal
    extremeEvents: string;
    co2Concentration: string; // Added
  };
  futureProjections2050: {
    scenario: string;
    temperature: string;
    precipitation: string;
    seaLevel?: string; // Optional
    floodRisk: string;
    droughtRisk: string;
    wildfireRisk: string; // Added
  };
  keyRisks: string[];
  mitigationAdvice: string[];
  adaptationHighlights: string[];
  imageSeedTrend: string; // Separate seed for trend chart
  imageSeedRisk: string;  // Separate seed for risk map
}

const generateReportData = (location: string, reportType: string, scenario: string): ReportData => {
  const isCoastal = reportType === "city" ? Math.random() > 0.35 : Math.random() > 0.25; // Cities slightly less likely coastal than random countries
  const currentYear = new Date().getFullYear();
  const baseYearHistorical = 1950 + Math.floor(Math.random() * 30); // Random base year from 1950-1979 for historical trends

  const trendsTemperature = `Average +${(Math.random() * 1.8 + 0.7).toFixed(1)}°C increase compared to ${baseYearHistorical}-${baseYearHistorical+20} baseline. Accelerated warming in recent decades.`;
  const trendsPrecipitation = `${(Math.random() * 20 + 5).toFixed(0)}% ${getRandomElement(["increase in heavy precipitation events", "decrease in overall annual rainfall", "shift in seasonal rainfall patterns", "more erratic distribution"])}.`;
  
  const sspScenariosDetails: {[key: string]: {tempRange: [number, number], slrMultiplier: number, riskFactor: number, description: string}} = {
    "SSP1-2.6": { tempRange: [1.5, 2.2], slrMultiplier: 0.8, riskFactor: 0.7, description: "Low Emissions & High Resilience Pathway"},
    "SSP2-4.5": { tempRange: [2.3, 3.2], slrMultiplier: 1.0, riskFactor: 1.0, description: "Medium Emissions & Moderate Resilience Pathway"},
    "SSP3-7.0": { tempRange: [3.3, 4.5], slrMultiplier: 1.3, riskFactor: 1.3, description: "High Emissions & Low Resilience Pathway"},
    "SSP5-8.5": { tempRange: [4.2, 5.8], slrMultiplier: 1.6, riskFactor: 1.6, description: "Very High Emissions & Fossil-fueled Development Pathway"}
  };
  const selectedScenarioDetails = sspScenariosDetails[scenario] || sspScenariosDetails["SSP2-4.5"];

  const projTempMin = selectedScenarioDetails.tempRange[0] + (Math.random() * 0.4 - 0.2);
  const projTempMax = selectedScenarioDetails.tempRange[1] + (Math.random() * 0.6 - 0.3);
  const projTemperature = `Projected average increase of +${projTempMin.toFixed(1)}°C to +${projTempMax.toFixed(1)}°C relative to pre-industrial levels. More frequent and intense heatwaves expected.`;
  
  const projPrecipitationPatterns = [
    "Increased frequency and intensity of extreme rainfall events, leading to higher flood risk, alternating with longer and more severe dry spells in many regions.",
    "Significant shifts in seasonal rainfall patterns, impacting water resource availability for agriculture, industry, and domestic use.",
    "Greater year-to-year variability in precipitation, making long-term water management and agricultural planning more challenging and uncertain.",
    `Overall ${Math.random() > 0.5 ? 'reduction' : 'increase'} in mean annual rainfall for ${location}, with pronounced regional differences and impacts on hydrology.`
  ];

  const riskLevels = ["Low", "Moderate", "Elevated", "High", "Very High", "Critical"];
  const getRiskLevel = (baseFactor: number) => riskLevels[Math.min(riskLevels.length - 1, Math.floor(Math.random() * 2 + baseFactor * selectedScenarioDetails.riskFactor))];


  const adaptationHighlightsPool = [
    "Implementation of advanced, integrated early warning systems for floods, heatwaves, droughts, and storms, tailored to local vulnerabilities.",
    "Development of climate-resilient infrastructure, including upgraded storm drainage, reinforced coastal defenses, and climate-proofed energy and transport networks.",
    "Promotion of water conservation and efficiency measures, development of drought-resistant agricultural varieties, and integrated water resource management plans.",
    "Expansion of urban greening projects (e.g., parks, green roofs, urban forests) to mitigate urban heat island effects, improve air quality, and manage stormwater.",
    "Strengthening community engagement programs for climate literacy, preparedness drills, and local adaptation planning, especially for vulnerable groups.",
    "Diversification of local economies and livelihoods to reduce dependence on climate-sensitive sectors and build adaptive capacity.",
    "Enhancement of ecosystem-based adaptation measures, such as mangrove restoration, reforestation, and soil conservation to bolster natural resilience.",
    "Investment in research and monitoring of local climate impacts to inform adaptive management and policy decisions.",
  ];

  const uniqueSeedSuffix = Date.now();

  return {
    location: `${location} (${reportType === "city" ? "City/Regional Focus" : "National Overview"})`,
    reportTitle: `Climate Trajectory & Resilience Report: ${location}`,
    dateGenerated: new Date().toLocaleString([], { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
    currentTrends: {
      temperature: trendsTemperature,
      precipitation: trendsPrecipitation,
      seaLevel: isCoastal ? `${(Math.random() * 10 + 4).toFixed(0)} cm rise observed since ${baseYearHistorical + 40}, with accelerated rise in recent years.` : undefined,
      extremeEvents: `Notable increase in frequency and/or intensity of ${getRandomElement(["heatwave days", "heavy precipitation events", "coastal storm intensity", "wildfire risk days", "flash floods", "prolonged droughts"])} observed in the last 15-25 years.`,
      co2Concentration: `Current atmospheric CO₂ levels contributing to observed changes: approx. ${(415 + Math.random()*15).toFixed(0)} ppm (global average).`
    },
    futureProjections2050: {
      scenario: `Based on ${scenario} (${selectedScenarioDetails.description})`,
      temperature: projTemperature,
      precipitation: getRandomElement(projPrecipitationPatterns),
      seaLevel: isCoastal ? `Additional ${(Math.random() * 25 + 15 * selectedScenarioDetails.slrMultiplier).toFixed(0)}-${(Math.random() * 35 + 30 * selectedScenarioDetails.slrMultiplier).toFixed(0)} cm rise anticipated, exacerbating coastal hazards.` : undefined,
      floodRisk: `Projected ${getRiskLevel(2)} risk from riverine, pluvial, and/or coastal flooding, particularly in low-lying and urbanized areas.`,
      droughtRisk: `Anticipated ${getRiskLevel(1.5)} risk of meteorological, agricultural, and/or hydrological drought, with implications for water security.`,
      wildfireRisk: `Expected ${getRiskLevel(1)} risk of wildfires, influenced by vegetation changes, temperature increases, and drought conditions.`,
    },
    keyRisks: getRandomElements(sampleKeyRisksPool, Math.floor(Math.random() * 3) + 4), // 4-6 risks
    mitigationAdvice: getRandomElements(sampleMitigationAdvicePool, Math.floor(Math.random() * 3) + 5), // 5-7 advice points
    adaptationHighlights: getRandomElements(adaptationHighlightsPool, Math.floor(Math.random() * 2) + 3), // 3-4 highlights
    imageSeedTrend: `${location.replace(/\s+/g, '')}Trend${uniqueSeedSuffix}`,
    imageSeedRisk: `${location.replace(/\s+/g, '')}Risk${uniqueSeedSuffix}`,
  };
};


export default function ReportGeneratorPage() {
  const [location, setLocation] = useState("");
  const [reportType, setReportType] = useState("city");
  const [scenario, setScenario] = useState("SSP2-4.5"); // Default scenario
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  
  // State for image seeds, initialized to ensure they are set on client
  const [imageSeedTrend, setImageSeedTrend] = useState<string | null>(null);
  const [imageSeedRisk, setImageSeedRisk] = useState<string | null>(null);

  useEffect(() => {
    // Initialize seeds on mount for client-side rendering consistency
    if (!imageSeedTrend) setImageSeedTrend(`TrendPlaceholder${Date.now()}`);
    if (!imageSeedRisk) setImageSeedRisk(`RiskPlaceholder${Date.now()}`);
  }, []);


  const handleGenerateReport = () => {
    if (!location) {
       toast({
        title: "Input Required",
        description: "Please enter a location name.",
        variant: "destructive",
      });
      return;
    }
    setLoading(true);
    setReportData(null); // Clear previous report

    // Simulate API call / data generation
    setTimeout(() => {
      const newReportData = generateReportData(location, reportType, scenario);
      setReportData(newReportData);
      // Update image seeds based on new report data for client-side image rendering
      setImageSeedTrend(newReportData.imageSeedTrend);
      setImageSeedRisk(newReportData.imageSeedRisk);
      setLoading(false);
      toast({
        title: "Report Generated Successfully!",
        description: `Climate trajectory report for ${location} is ready for review.`,
      });
    }, 1800 + Math.random() * 700);
  };

  const handleDownloadPdf = () => {
    // This is a simulation. In a real app, you'd generate a PDF.
    toast({
      title: "Download PDF Initiated (Simulated)",
      description: "Your report is being prepared for download. This feature is illustrative and does not generate a real PDF.",
      variant: "default",
    });
    
    // Simulate a delay for PDF generation
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "PDF Ready (Simulated)",
        description: `Climate_Report_for_${(reportData?.location.split(" (")[0].replace(/\s+/g, '_') || "Location")}_${scenario}.pdf would be downloaded here.`,
      });
    }, 2500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
         <div>
            <h1 className="text-3xl font-bold tracking-tight text-primary">Climate Report Generator</h1>
            <p className="text-muted-foreground">Generate a custom climate trajectory report with simulated data insights and visualizations.</p>
        </div>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><FileText className="text-primary"/>Report Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="locationInput" className="block text-sm font-medium text-foreground mb-1">City or Country Name</label>
              <Input
                id="locationInput"
                type="text"
                placeholder="e.g., New York City or USA"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="reportTypeSelect" className="block text-sm font-medium text-foreground mb-1">Report Scope</label>
              <Select value={reportType} onValueChange={(value) => setReportType(value)}>
                <SelectTrigger id="reportTypeSelect">
                  <SelectValue placeholder="Select report type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="city">City/Regional Report</SelectItem>
                  <SelectItem value="country">National Report</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label htmlFor="scenarioSelect" className="block text-sm font-medium text-foreground mb-1">Projection Scenario (IPCC)</label>
              <Select value={scenario} onValueChange={(value) => setScenario(value)}>
                <SelectTrigger id="scenarioSelect">
                  <SelectValue placeholder="Select projection scenario" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="SSP1-2.6">SSP1-2.6 (Low Emissions)</SelectItem>
                  <SelectItem value="SSP2-4.5">SSP2-4.5 (Medium Emissions)</SelectItem>
                  <SelectItem value="SSP3-7.0">SSP3-7.0 (High Emissions)</SelectItem>
                  <SelectItem value="SSP5-8.5">SSP5-8.5 (Very High Emissions)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button onClick={handleGenerateReport} disabled={loading || !location} className="w-full md:w-auto">
            {loading ? "Generating Report..." : "Generate Climate Report"}
          </Button>
        </CardContent>
      </Card>
      
      {loading && !reportData && (
        <Card className="shadow-lg text-center py-10">
            <CardHeader>
                <CardTitle>Generating your climate report for {location}...</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="animate-pulse flex flex-col items-center">
                    <FileText className="w-16 h-16 text-primary mb-4" />
                    <p className="text-muted-foreground">Analyzing climate models and compiling data... (Simulated)</p>
                </div>
            </CardContent>
        </Card>
      )}

      {reportData && !loading && (
        <Card className="shadow-xl">
          <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <CardTitle className="text-2xl text-primary">{reportData.reportTitle}</CardTitle>
              <CardDescription>Generated on: {reportData.dateGenerated} (Simulated Data based on IPCC Frameworks)</CardDescription>
            </div>
            <Button variant="outline" size="lg" onClick={handleDownloadPdf} disabled={loading} className="w-full sm:w-auto">
              <Download className="mr-2 h-5 w-5" />
              Download PDF (Simulated)
            </Button>
          </CardHeader>
          <CardContent className="space-y-6 pt-6">
            <ReportSection title="Current Climate Trends & Observations" icon={Thermometer}>
              <p><strong>Temperature:</strong> {reportData.currentTrends.temperature}</p>
              <p><strong>Precipitation:</strong> {reportData.currentTrends.precipitation}</p>
              {reportData.currentTrends.seaLevel && <p><strong>Sea Level:</strong> {reportData.currentTrends.seaLevel}</p>}
              <p><strong>Extreme Events:</strong> {reportData.currentTrends.extremeEvents}</p>
              <p><strong>CO₂ Context:</strong> {reportData.currentTrends.co2Concentration}</p>
            </ReportSection>
            
            <ReportSection title={`Future Projections (Towards 2050 - ${reportData.futureProjections2050.scenario})`} icon={Sun}>
              <p><strong>Temperature:</strong> {reportData.futureProjections2050.temperature}</p>
              <p><strong>Precipitation:</strong> {reportData.futureProjections2050.precipitation}</p>
              {reportData.futureProjections2050.seaLevel && <p><strong>Sea Level:</strong> {reportData.futureProjections2050.seaLevel}</p>}
              <p><strong>Flood Risk:</strong> {reportData.futureProjections2050.floodRisk}</p>
              <p><strong>Drought Risk:</strong> {reportData.futureProjections2050.droughtRisk}</p>
              <p><strong>Wildfire Risk:</strong> {reportData.futureProjections2050.wildfireRisk}</p>
              <div className="mt-4 grid md:grid-cols-2 gap-4">
                 <div className="h-60 bg-muted rounded-md flex flex-col items-center justify-center p-2">
                    <h4 className="text-sm font-semibold text-muted-foreground mb-1">Conceptual Temperature Trend</h4>
                    {imageSeedTrend && <Image 
                        src={`https://picsum.photos/seed/${imageSeedTrend}/400/220`}
                        alt="Temperature Trend Chart Placeholder"
                        width={400}
                        height={220}
                        className="rounded-md object-contain"
                        data-ai-hint="climate chart temperature"
                        key={imageSeedTrend} 
                    />}
                 </div>
                 <div className="h-60 bg-muted rounded-md flex flex-col items-center justify-center p-2">
                    <h4 className="text-sm font-semibold text-muted-foreground mb-1">Conceptual Hazard Hotspots</h4>
                    {imageSeedRisk && <Image 
                        src={`https://picsum.photos/seed/${imageSeedRisk}/400/220`}
                        alt="Flood Risk Map Placeholder"
                        width={400}
                        height={220}
                        className="rounded-md object-contain"
                        data-ai-hint="flood map risk"
                        key={imageSeedRisk}
                    />}
                 </div>
              </div>
               <p className="text-xs text-muted-foreground mt-1 text-center">Placeholder charts and maps. Actual data visualization will be included in the final report.</p>
            </ReportSection>

            <ReportSection title="Key Climate-Related Risks Identified" icon={AlertTriangle}>
              <ul className="list-disc list-inside space-y-1 columns-1 md:columns-2">
                {reportData.keyRisks.map((risk, index) => <li key={index}>{risk}</li>)}
              </ul>
            </ReportSection>
            
            <ReportSection title="Highlighted Adaptation Measures & Strategies" icon={ShieldCheck}>
              <ul className="list-disc list-inside space-y-1">
                {reportData.adaptationHighlights.map((advice, index) => <li key={index}>{advice}</li>)}
              </ul>
            </ReportSection>

            <ReportSection title="Suggested Mitigation Efforts & Long-Term Resilience Pathways" icon={Leaf}>
              <ul className="list-disc list-inside space-y-1 columns-1 md:columns-2">
                {reportData.mitigationAdvice.map((advice, index) => <li key={index}>{advice}</li>)}
              </ul>
            </ReportSection>
          </CardContent>
           <CardFooter>
            <p className="text-xs text-muted-foreground">Disclaimer: This report is generated using simulated data based on generalized climate models and IPCC scenarios for educational and awareness purposes. It is not a substitute for detailed, location-specific scientific assessments conducted by climate experts and official meteorological agencies. Always consult with qualified professionals for critical decision-making.</p>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}

interface ReportSectionProps {
  title: string;
  children: React.ReactNode;
  icon: React.ElementType;
}
const ReportSection = ({title, children, icon: Icon}: ReportSectionProps) => (
  <section>
    <h3 className="text-xl font-semibold mb-3 pb-2 border-b border-border text-secondary flex items-center gap-2">
      <Icon className="w-6 h-6"/>
      {title}
    </h3>
    <div className="space-y-2 text-sm text-foreground/90">
      {children}
    </div>
  </section>
);


      