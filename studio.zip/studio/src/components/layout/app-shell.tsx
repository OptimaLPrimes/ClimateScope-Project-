
"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  LayoutDashboard,
  MapPin,
  TrendingUp,
  ShieldAlert,
  FileText,
  Settings,
  LogOut,
  Globe,
  Menu,
  Briefcase, // Example for a new item
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"


interface NavItemProps {
  href: string;
  icon: React.ElementType;
  label: string;
  tooltip?: string;
  exactMatch?: boolean;
}

const NavItem = ({ href, icon: Icon, label, tooltip, exactMatch = false }: NavItemProps) => {
  const pathname = usePathname();
  // For the root path ("/"), exact match is usually desired.
  // For other paths, allow prefix matching unless exactMatch is true.
  const isActive = exactMatch ? pathname === href : pathname.startsWith(href) && (href !== "/" || pathname === "/");
  const { open, isMobile, setOpenMobile } = useSidebar();

  const handleClick = () => {
    if (isMobile) {
      setOpenMobile(false);
    }
  };

  return (
    <SidebarMenuItem>
      <Link href={href} passHref legacyBehavior>
        <SidebarMenuButton
          asChild
          isActive={isActive}
          variant="default"
          tooltip={open ? undefined : tooltip || label}
          className={cn(
            isActive && "bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90 hover:text-sidebar-primary-foreground"
          )}
          onClick={handleClick}
        >
          <a>
            <Icon className="shrink-0" />
            <span className={cn("truncate", !open && "sr-only")}>{label}</span>
          </a>
        </SidebarMenuButton>
      </Link>
    </SidebarMenuItem>
  );
};

const navItems: NavItemProps[] = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard", tooltip: "Global Dashboard", exactMatch: true },
  { href: "/city-tracker", icon: MapPin, label: "City Tracker", tooltip: "Track Your City" },
  { href: "/future-simulator", icon: TrendingUp, label: "Future Simulator", tooltip: "Simulate Future" },
  { href: "/risk-estimator", icon: ShieldAlert, label: "Risk Estimator", tooltip: "Estimate Climate Risk" },
  { href: "/report-generator", icon: FileText, label: "Report Generator", tooltip: "Generate Report" },
  // Example of adding a new nav item
  // { href: "/resources", icon: Briefcase, label: "Resources", tooltip: "Climate Resources"},
];

function AppShellUI({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const pathname = usePathname();
  const { open, isMobile, setOpenMobile } = useSidebar();

  const getPageTitle = () => {
    const currentNavItem = navItems.find(item => item.exactMatch ? pathname === item.href : pathname.startsWith(item.href));
    return currentNavItem ? currentNavItem.label : "ClimateScope";
  };
  
  const handleLogout = () => {
    toast({
        title: "Logged Out (Simulated)",
        description: "You have been successfully logged out.",
        variant: "default"
    });
    // Add actual logout logic here, e.g., redirecting to login page or clearing session
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar collapsible="icon" variant="sidebar" className="border-r border-sidebar-border">
        <SidebarHeader className="p-4">
          <Link href="/" className="flex items-center gap-2 text-sidebar-foreground hover:text-sidebar-accent-foreground">
            <Globe className="h-8 w-8 text-sidebar-primary" />
            <span className="text-xl font-semibold truncate group-data-[collapsible=icon]:hidden">ClimateScope</span>
          </Link>
        </SidebarHeader>
        <Separator className="bg-sidebar-border" />
        <SidebarContent className="p-2">
          <SidebarMenu>
            {navItems.map((item) => (
              <NavItem key={item.href} {...item} />
            ))}
          </SidebarMenu>
        </SidebarContent>
        <Separator className="bg-sidebar-border" />
        <SidebarFooter className="p-4 space-y-2">
          <div className="flex items-center gap-2 group-data-[collapsible=icon]:justify-center">
             <Avatar className="h-8 w-8">
              <AvatarImage src="https://picsum.photos/seed/user/40/40" alt="User" data-ai-hint="user avatar" />
              <AvatarFallback>CS</AvatarFallback>
            </Avatar>
            <div className="flex flex-col truncate group-data-[collapsible=icon]:hidden">
              <span className="text-sm font-medium text-sidebar-foreground">Climate User</span>
              <span className="text-xs text-sidebar-foreground/70">user@climatescope.com</span>
            </div>
          </div>
           <AlertDialog>
            <AlertDialogTrigger asChild>
                <Button 
                    variant="ghost" 
                    className="w-full justify-start p-2 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:aspect-square text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                    title="Logout"
                >
                    <LogOut className="h-5 w-5 shrink-0" />
                    <span className="ml-2 group-data-[collapsible=icon]:sr-only">Logout</span>
                </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
                <AlertDialogHeader>
                <AlertDialogTitle>Confirm Logout</AlertDialogTitle>
                <AlertDialogDescription>
                    Are you sure you want to log out of ClimateScope?
                </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleLogout}>Logout</AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset className="flex flex-col flex-1">
        <header className="sticky top-0 z-10 flex items-center justify-between h-16 px-4 bg-background/80 backdrop-blur-sm border-b">
          <div className="flex items-center gap-2">
            <SidebarTrigger className="md:hidden" onClick={() => setOpenMobile(!openMobile)}>
               <Menu />
            </SidebarTrigger>
            <h1 className="text-xl font-semibold text-foreground">{getPageTitle()}</h1>
          </div>
           <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Open settings">
                <Settings className="h-5 w-5" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Application Settings</AlertDialogTitle>
                <AlertDialogDescription>
                  This is a placeholder for application settings. Customize your experience here in a future update.
                  Current options might include theme selection, notification preferences, or data source configurations.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="py-4">
                <p className="text-sm text-muted-foreground">Example Setting: Dark Mode (Coming Soon)</p>
                 <p className="text-sm text-muted-foreground mt-2">Example Setting: Email Notifications (Coming Soon)</p>
              </div>
              <AlertDialogFooter>
                <AlertDialogCancel>Close</AlertDialogCancel>
                <AlertDialogAction onClick={() => toast({title: "Settings Saved (Simulated)", description: "Your preferences would be saved here."})}>Save Changes</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </header>
        <main className="flex-1 p-6 overflow-auto bg-muted/30">
          {children}
        </main>
      </SidebarInset>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const isMobileInitial = useIsMobile();

  return (
    <SidebarProvider 
      defaultOpen={!isMobileInitial} 
      open={isMobileInitial ? false : undefined}
    >
      <AppShellUI>{children}</AppShellUI>
    </SidebarProvider>
  );
}
