(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f97cc15d._.js",
  "static/chunks/src_7765ce2d._.js"
],
    source: "dynamic"
});
