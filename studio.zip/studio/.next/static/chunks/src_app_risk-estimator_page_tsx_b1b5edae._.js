(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_risk-estimator_page_tsx_b1b5edae._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_risk-estimator_page_tsx_b1b5edae._.js",
  "chunks": [
    "static/chunks/node_modules_d48151f6._.js",
    "static/chunks/src_55e7c359._.js"
  ],
  "source": "dynamic"
});
