(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_6c60c00e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_6c60c00e._.js",
  "chunks": [
    "static/chunks/node_modules_61ed6c2e._.js",
    "static/chunks/src_components_ui_select_tsx_b3bb367d._.js"
  ],
  "source": "dynamic"
});
