(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_components_maps_interactive-climate-map_tsx_cfe16ed2._.js", {

"[project]/src/components/maps/interactive-climate-map.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_d0268d00._.js",
  "static/chunks/src_components_maps_interactive-climate-map_tsx_9ebe81b5._.js",
  "static/chunks/src_components_maps_interactive-climate-map_tsx_3e26fd82._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/maps/interactive-climate-map.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);