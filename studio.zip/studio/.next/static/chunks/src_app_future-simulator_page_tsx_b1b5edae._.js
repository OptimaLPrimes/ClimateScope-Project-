(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_future-simulator_page_tsx_b1b5edae._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_future-simulator_page_tsx_b1b5edae._.js",
  "chunks": [
    "static/chunks/node_modules_3b1c4065._.js",
    "static/chunks/src_7fa2f45d._.js"
  ],
  "source": "dynamic"
});
