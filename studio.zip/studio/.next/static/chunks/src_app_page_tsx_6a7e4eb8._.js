(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_6a7e4eb8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_6a7e4eb8._.js",
  "chunks": [
    "static/chunks/node_modules_5b6edd59._.js",
    "static/chunks/src_684b8f7e._.js"
  ],
  "source": "dynamic"
});
