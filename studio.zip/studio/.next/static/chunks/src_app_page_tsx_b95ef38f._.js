(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c1aa2c94._.js",
  "static/chunks/src_684b8f7e._.js"
],
    source: "dynamic"
});
