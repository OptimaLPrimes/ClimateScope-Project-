(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_report-generator_page_tsx_b1b5edae._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_report-generator_page_tsx_b1b5edae._.js",
  "chunks": [
    "static/chunks/node_modules_84d8ee19._.js",
    "static/chunks/src_0ce9c9cf._.js"
  ],
  "source": "dynamic"
});
