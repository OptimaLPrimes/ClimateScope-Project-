(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_49a6ea35._.js",
  "static/chunks/node_modules_next_dist_compiled_2ce9398a._.js",
  "static/chunks/node_modules_next_dist_client_43e3ffb8._.js",
  "static/chunks/node_modules_next_dist_3bfaed20._.js",
  "static/chunks/node_modules_@swc_helpers_cjs_00636ac3._.js"
],
    source: "entry"
});
