(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_da97ff11._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_da97ff11._.js",
  "chunks": [
    "static/chunks/src_components_maps_interactive-climate-map_tsx_cfe16ed2._.js",
    "static/chunks/node_modules_fb71ded1._.js",
    "static/chunks/src_684b8f7e._.js"
  ],
  "source": "dynamic"
});
