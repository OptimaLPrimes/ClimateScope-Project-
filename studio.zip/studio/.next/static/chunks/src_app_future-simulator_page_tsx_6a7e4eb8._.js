(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_future-simulator_page_tsx_6a7e4eb8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_future-simulator_page_tsx_6a7e4eb8._.js",
  "chunks": [
    "static/chunks/node_modules_a758c11f._.js",
    "static/chunks/src_7fa2f45d._.js"
  ],
  "source": "dynamic"
});
