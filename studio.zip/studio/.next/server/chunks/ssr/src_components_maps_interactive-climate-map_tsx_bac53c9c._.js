module.exports = {

"[project]/src/components/maps/interactive-climate-map.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_0def4969._.js",
  "server/chunks/ssr/src_components_maps_interactive-climate-map_tsx_52846af2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/maps/interactive-climate-map.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};