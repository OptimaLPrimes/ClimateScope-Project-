# **App Name**: ClimateScope

## Core Features:

- Interactive Climate Map: Interactive map to visualize global climate data with heatmaps showing temperature rise, CO₂ emissions, and sea-level changes.
- City Climate Tracker: Allows users to enter their city or drop a pin on a map to retrieve and display relevant climate data like temperature changes, rainfall anomalies, and sea-level rise.
- Climate Future Simulator: Simulates future climate scenarios for a user's city in 2050 based on IPCC projections, including expected temperature, rainfall, flood risk, and wildfire/drought likelihoods.
- Climate Risk Estimator: Tool that calculates a climate vulnerability index (CVI) based on user inputs like region type, local emission levels, and vegetation cover, then suggests climate resilience actions.
- Climate Report Generator: Generates a PDF report of a selected city or country's climate trajectory, including charts, insights, risks, and mitigation advice, useful for school projects or civic awareness.

## Style Guidelines:

- Primary color: Deep blue (#003049) to represent the ocean and atmosphere.
- Secondary color: Earthy green (#386641) to symbolize land and vegetation.
- Accent color: Warning Orange (#D62828) to highlight areas of critical climate impact
- Clean, modern layout with clear sections for each feature.
- Use clear, intuitive icons to represent different climate variables and actions.
- Subtle animations to transition between different data visualizations.